#include <iostream>
#include <cstring>
#include <stdlib.h>
#include <cmath>
#include <atomic>
#include <queue>
#include <mutex>
#include <thread>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <vector>
#include <condition_variable>
#include <array>
#include <assert.h>

using namespace std;

const uint64_t queue_uint64_thres = 1 << 11;

struct config_t {
/* read only variables */
	uint64_t  nodes;		// # of nodes
	uint64_t  level;	        // # of levels
	uint64_t  groups;	 	// # of groups
	uint64_t* map_table;	 	// # shuffled mapping table
	uint64_t  total_threads;	// # of threads, defined by user
        uint64_t  wmax;
        uint64_t  thres;
	uint64_t  period;
	uint64_t barrier_period;
	std::chrono::duration<double>* time;
/* shared variables */

//	uint64_t finished_threads;
	uint64_t failed_nodes;	// # of failed nodes
//	uint64_t* group_writes;
	uint64_t total_writes;
	uint64_t blocking_threads;	
	std::condition_variable_any cv;
        std::mutex mutex;	// queue lock 
};
void consume_path_oram_requests(config_t* config, uint64_t id);
int increment_memory_line(uint64_t la, config_t* config);
inline void leaf_range(uint64_t level, uint64_t &from, uint64_t &to);
//inline int check_group(uint64_t la, uint64_t thread_id, uint64_t group_size_max, uint64_t total_threads);
//inline uint64_t my_random_generator(uint64_t from, uint64_t to, uint64_t counter);
