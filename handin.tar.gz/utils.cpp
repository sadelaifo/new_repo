#include "utils.h"

inline void leaf_range(const uint64_t level, uint64_t &from, uint64_t &to) {
	from = (uint64_t) (1 << (level - 1)) - 1;
	to   = (uint64_t) (1 << level) - 2;
}

inline int check_group(uint64_t la, uint64_t thread_id, uint64_t group_size_max, uint64_t groups_per_thread) {
	uint64_t group_id = la / group_size_max;
	return ((group_id / groups_per_thread) == thread_id);
}

inline uint64_t my_random_generator(uint64_t from, uint64_t to, uint64_t counter) {
	return (uint64_t) rand() % (to - from + 1) + from;
	return counter % (to - from + 1) + from;
}

inline int initialize_consumer_thread(
	config_t* config, 
	uint64_t** &pa, 
	uint64_t* &map_table,
	uint64_t* &start, 
	uint64_t* &gap, 
	uint64_t* &group_counter, 
	uint64_t* &group_size, 
	uint64_t  groups_this_thread,
	uint64_t  group_size_max,
	uint64_t  total_threads,
	uint64_t  my_id) {
	try {
                pa              = new uint64_t*[groups_this_thread];
                start           = new uint64_t [groups_this_thread];
                gap             = new uint64_t [groups_this_thread];
                group_counter   = new uint64_t [groups_this_thread];
                group_size      = new uint64_t [groups_this_thread];
//              map_table       = new uint64_t [nodes];
        } catch (std::bad_alloc& ba) {
                std::cerr << "bad allocation caught " << ba.what() << std::endl;
                return 1;
        }
//      memcpy(map_table, config->map_table, sizeof(uint64_t) * nodes);
        map_table = config->map_table;
        memset(group_counter, 0, sizeof(uint64_t) * groups_this_thread);
        memset(start,         0, sizeof(uint64_t) * groups_this_thread);
        for (uint64_t i = 0; i < groups_this_thread; i++) {
                try {
                        pa[i] = new uint64_t [group_size_max + 1];
                } catch (std::bad_alloc& ba) {
                        std::cerr << "bad allocation caught" << ba.what() << std::endl;
                        return 1;
                }
                group_size[i]           = group_size_max;
                gap[i]                  = group_size_max;
                memset(pa[i], 0, sizeof(uint64_t) * (group_size_max + 1));
        }

        if (my_id == total_threads - 1) {
                group_size[groups_this_thread - 1] = config->nodes - group_size_max * (config->groups - 1) + 1;
                gap[groups_this_thread - 1] = group_size[groups_this_thread - 1] + 1;
        }
	return 0;
}

inline int consumer_thread_wait(config_t* config, const uint64_t thres, const uint64_t counter, const uint64_t barrier_period, uint64_t &failed_nodes_local, uint64_t& total_writes_local) {
	if (counter % barrier_period == 0) {
		config->failed_nodes += failed_nodes_local;
		config->thread_barrier->wait();
		if (config->failed_nodes.load() >= thres) {
			config->total_writes += total_writes_local;
			// config->time[my_id] = std::chrono::system_clock::now() - start_time;
			return 1;
		}
		failed_nodes_local = 0;
	}
	return 0;
}

void consume_path_oram_requests(config_t* config, uint64_t my_id) {
	auto init_time = std::chrono::system_clock::now();
	const uint64_t  nodes           = config->nodes;
	const uint64_t  wmax            = config->wmax;
	const uint64_t  thres           = config->thres;
	const uint64_t  period 		= config->period;
	const uint64_t  group_size_max  = (uint64_t)ceil((double)nodes / (double)config->groups);
	uint64_t la = 0;
	uint64_t from = 0;
	uint64_t to = 0;
	const uint64_t level = config->level;
	leaf_range(level, from, to);
	const uint64_t barrier_period = config->barrier_period;
	uint64_t counter = 0;
	uint64_t failed_nodes_local = 0;
	uint64_t total_threads = config->total_threads;
	uint64_t **pa;
	uint64_t *start;
	uint64_t *gap;
	uint64_t *group_counter;
	uint64_t groups_per_thread = (uint64_t)ceil((double)config->groups / (double)config->total_threads);
	uint64_t groups_this_thread = (my_id == (total_threads - 1)) ? (config->groups - my_id * groups_per_thread) : groups_per_thread;
	uint64_t *group_size;
	uint64_t total_writes_local = 0;
	uint64_t *map_table;
	// init physical address array, 
	// start, gap, counter
	if (initialize_consumer_thread(
				config, 
				pa, 
				map_table,
				start, 
				gap, 
				group_counter, 
				group_size, 
				groups_this_thread, 
				group_size_max, 
				total_threads, 
				my_id) == 1) {
		std::cerr << "ERROR, consumer thread init fails\n";
		return;
	}

	std::chrono::duration<double> init_elapsed_time = std::chrono::system_clock::now() - init_time;

	// finish init
	std::cout << "Thread " << my_id << " has finished init within " << init_elapsed_time.count() << "seconds\n";

	auto start_time = std::chrono::system_clock::now();

	while (1) {
		// get a job from request queue
		uint64_t leaf_id = my_random_generator(from, to, counter);
		for (uint64_t i = 0; i < level; i++) {
			counter++;
			//			la = transfer_matrix(leaf_id);
			la = map_table[leaf_id];
			leaf_id = (leaf_id - 1) >> 1;
			// then process the job
			if (check_group(la, my_id, group_size_max, groups_per_thread) == 1) {
				// increment_memory_line
				//				assert(la / group_size_max < groups_per_thread);
				uint64_t  group_id      =  (la / group_size_max) % groups_per_thread;

				// perform start-gap logic
				la = la % group_size_max;
				uint64_t tmp_pa = (la + start[group_id]) % group_size[group_id];
				tmp_pa = tmp_pa < gap[group_id] ? tmp_pa : tmp_pa + 1;
				(group_counter[group_id])++;
				(pa[group_id][tmp_pa])++;
				if (pa[group_id][tmp_pa] >= wmax) {
					failed_nodes_local++;
					pa[group_id][tmp_pa] = 0;
				}
				if (group_counter[group_id] % period == 0) {
					(gap[group_id])--;
					if (gap[group_id] == 0) {
						gap[group_id] = group_size[group_id];
						start[group_id] = (start[group_id] + 1) % (gap[group_id]);
					}
				}
				total_writes_local++;
			}
			if (consumer_thread_wait(config, thres, counter, barrier_period, failed_nodes_local, total_writes_local) == 1) {
				return;
			}
		}
	}
	config->cv.notify_all();
	std::cerr << "error, shouldn't come here \n";
	return;
}

//inline void my_barrier(config_t* config, uint64_t failed_nodes_local, uint64_t total_writes_local, )

// return 1 if # of failed nodes > threshold
// return 0 on a success start-gap update of memory
/*

   int increment_memory_line(uint64_t la, config_t* config, uint64_t &failed_nodes_local) {
   const uint64_t  nodes 		= config->nodes;
   const uint64_t  wmax 		= config->wmax;
   const uint64_t  thres		= config->thres;
   const uint64_t  group_size_max 	= ceil(nodes / config->groups);
   uint64_t  group_id      =  la / group_size_max;
   uint64_t* pa            =  config->pa[group_id];
   uint64_t* start 	= &config->start[group_id];
   uint64_t* gap 		= &config->gap[group_id];

// perform start-gap logic
la = la % group_size_max;
uint64_t tmp_pa = (la + *start) % config->group_size[group_id];
tmp_pa = tmp_pa < *gap ? tmp_pa : tmp_pa + 1;
(config->group_counter[group_id])++;
(pa[tmp_pa])++;
if (pa[tmp_pa] >= wmax) {
failed_nodes_local++;
pa[tmp_pa] = 0;
}
if (config->group_counter[group_id] % config->period == 0) {
(*gap)--;
if (*gap == 0) {
 *gap = config->group_size[group_id];
 *start = (*start + 1) % (*gap);
 }
 }

 return 0;
 }

 */
